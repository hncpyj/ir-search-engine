"""
Cross-domain evaluation — automated, no manual annotation required.

Replaces the manual two-annotator protocol with automated relevance proxies:

  - domain_coverage@10: fraction of queries where top-10 spans ≥2 domains.
  - mean_domains_in_top10: average number of distinct domains in top-10.
  - expected_domain_hit@10: fraction of queries where all expected domains
      appear in top-10 results.
  - keyword_ndcg@10: nDCG@10 using keyword-overlap relevance as a proxy
      (0 = no overlap, 1 = partial, 2 = strong overlap).

For the "Cohen's κ" equivalent we report pairwise agreement between two
automated relevance signals (BM25 keyword overlap vs dense cosine rank),
which simulates inter-annotator agreement without human effort.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path

import numpy as np

logger = logging.getLogger(__name__)

QUERIES_PATH = Path(__file__).parent.parent.parent / "data" / "cross_domain" / "queries.jsonl"

STOPWORDS = {
    "a", "an", "the", "of", "in", "for", "to", "and", "or", "is", "are",
    "with", "on", "at", "by", "from", "that", "this", "it", "be", "as",
    "its", "into", "using", "how", "what", "between", "effects", "impact",
    "role", "use", "based", "via", "through", "under",
}


# ---------------------------------------------------------------------------
# Query loading
# ---------------------------------------------------------------------------

def load_cross_domain_queries(path: Path = QUERIES_PATH) -> list[dict]:
    """Load queries.jsonl → list of {query_id, text, expected_domains}."""
    queries = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                queries.append(json.loads(line))
    return queries


# ---------------------------------------------------------------------------
# Automated relevance scoring
# ---------------------------------------------------------------------------

def _tokenise(text: str) -> set[str]:
    tokens = re.findall(r"[a-z]+", text.lower())
    return {t for t in tokens if t not in STOPWORDS and len(t) > 2}


def keyword_relevance(query_text: str, doc_title: str, doc_text: str) -> int:
    """
    Automated relevance proxy using keyword overlap (0, 1, 2).
      2 = strong overlap (≥35% of query terms match)
      1 = partial overlap (≥12%)
      0 = no meaningful overlap
    """
    q_tokens = _tokenise(query_text)
    if not q_tokens:
        return 0
    d_tokens = _tokenise(f"{doc_title} {doc_text}")
    hits = len(q_tokens & d_tokens)
    ratio = hits / len(q_tokens)
    if ratio >= 0.35:
        return 2
    if ratio >= 0.12:
        return 1
    return 0


# ---------------------------------------------------------------------------
# Automated κ-equivalent: agreement between two relevance signals
# ---------------------------------------------------------------------------

def automated_agreement(
    labels_a: list[int],
    labels_b: list[int],
) -> float:
    """
    Linearly-weighted Cohen's κ between two automated relevance signals.
    Both signals use the same keyword_relevance function but applied to
    different text fields (title-only vs full text), simulating two annotators.
    """
    from sklearn.metrics import cohen_kappa_score
    if len(set(labels_a)) == 1 and len(set(labels_b)) == 1:
        return 1.0 if labels_a[0] == labels_b[0] else 0.0
    try:
        return float(cohen_kappa_score(labels_a, labels_b, weights="linear"))
    except Exception:
        return float("nan")


# ---------------------------------------------------------------------------
# nDCG@10 using keyword relevance as ground truth
# ---------------------------------------------------------------------------

def _dcg(relevances: list[int], k: int = 10) -> float:
    gains = [rel / np.log2(i + 2) for i, rel in enumerate(relevances[:k])]
    return float(np.sum(gains))


def keyword_ndcg_at_k(
    query_text: str,
    results: list,
    k: int = 10,
) -> float:
    """nDCG@k where relevance is determined by keyword_relevance()."""
    rels = [
        keyword_relevance(query_text, r.title or "", r.text or "")
        for r in results[:k]
    ]
    ideal = sorted(rels, reverse=True)
    dcg = _dcg(rels, k)
    idcg = _dcg(ideal, k)
    return dcg / idcg if idcg > 0 else 0.0


# ---------------------------------------------------------------------------
# Main evaluation function
# ---------------------------------------------------------------------------

def evaluate_cross_domain(
    results_by_qid: dict[str, list],
    queries: list[dict],
    top_n: int = 10,
) -> dict:
    """
    Compute cross-domain retrieval metrics (no human annotation required).

    Metrics:
      - domain_coverage@N: fraction of queries with ≥2 domains in top-N
      - mean_domains_in_topN: average distinct domains in top-N
      - expected_domain_hit@N: fraction of queries where ALL expected domains
          appear somewhere in top-N
      - keyword_ndcg@N: mean nDCG@N using keyword overlap as relevance proxy
      - automated_kappa: mean Cohen's κ between title-based and full-text-based
          relevance signals (automated inter-annotator agreement equivalent)

    Args:
        results_by_qid: {query_id: [RetrievalResult, ...]}
        queries:        list of {query_id, text, expected_domains}
        top_n:          rank cutoff

    Returns:
        dict of metric name → value
    """
    query_map = {q["query_id"]: q for q in queries}

    coverage_scores: list[float] = []
    domain_counts: list[int] = []
    expected_hits: list[float] = []
    ndcg_scores: list[float] = []
    kappa_scores: list[float] = []

    for qid, results in results_by_qid.items():
        q = query_map.get(qid, {})
        query_text = q.get("text", "")
        expected = set(q.get("expected_domains", []))
        top_results = results[:top_n]

        # Domain coverage
        domains_in_top = {r.domain for r in top_results}
        domain_counts.append(len(domains_in_top))
        coverage_scores.append(1.0 if len(domains_in_top) >= 2 else 0.0)

        # Expected domain hit
        if expected:
            hit = expected.issubset(domains_in_top)
            expected_hits.append(1.0 if hit else 0.0)

        # Keyword nDCG@N
        ndcg_scores.append(keyword_ndcg_at_k(query_text, top_results, top_n))

        # Automated κ: title-only vs full-text relevance signals
        labels_title = [
            keyword_relevance(query_text, r.title or "", "")
            for r in top_results
        ]
        labels_full = [
            keyword_relevance(query_text, r.title or "", r.text or "")
            for r in top_results
        ]
        kappa_scores.append(automated_agreement(labels_title, labels_full))

        logger.info(
            f"  {qid}: domains={sorted(domains_in_top)}, "
            f"nDCG@{top_n}={ndcg_scores[-1]:.3f}, κ={kappa_scores[-1]:.3f}"
        )

    valid_kappas = [k for k in kappa_scores if not np.isnan(k)]

    return {
        f"domain_coverage@{top_n}": float(np.mean(coverage_scores)) if coverage_scores else 0.0,
        f"mean_domains_in_top{top_n}": float(np.mean(domain_counts)) if domain_counts else 0.0,
        f"expected_domain_hit@{top_n}": float(np.mean(expected_hits)) if expected_hits else 0.0,
        f"keyword_nDCG@{top_n}": float(np.mean(ndcg_scores)) if ndcg_scores else 0.0,
        "automated_kappa": float(np.mean(valid_kappas)) if valid_kappas else float("nan"),
        "n_queries": len(results_by_qid),
    }
